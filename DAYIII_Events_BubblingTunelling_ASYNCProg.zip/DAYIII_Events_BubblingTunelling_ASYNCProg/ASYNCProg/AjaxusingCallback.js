function GetData(url,callbackFunc){
    var xmlhttpReq = new XMLHttpRequest();
    xmlhttpReq.open('GET',url);
    xmlhttpReq.onreadystatechange = function(){
        if(xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200){
            callbackFunc(xmlhttpReq.responseText);
        }
    }
    xmlhttpReq.send();// actually places an AJAX request !
}
