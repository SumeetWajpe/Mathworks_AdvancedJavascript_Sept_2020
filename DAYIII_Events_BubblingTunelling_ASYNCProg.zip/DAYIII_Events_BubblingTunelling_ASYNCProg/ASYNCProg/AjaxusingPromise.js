function GetData(url){
    return new Promise((resolve,reject)=>{
        // AJAX 
        var xmlhttpReq = new XMLHttpRequest();
        xmlhttpReq.open('GET',url);
        xmlhttpReq.onreadystatechange = function(){
            if(xmlhttpReq.readyState == 4 && xmlhttpReq.status == 200){
                resolve(xmlhttpReq.responseText);
            }
            else if(xmlhttpReq.readyState == 4 && xmlhttpReq.status !== 200){
                reject(xmlhttpReq.status)
            }
        }
        xmlhttpReq.send();// actually places an AJAX request !
    })
}