import Addition,* as MathModule from './MathModule.js';
console.log('The addition is : ' + Addition(30,40));
 console.log('The product is : ' + MathModule.Product(2,5));

// import Addition,{Product} from './MathModule.js';
// console.log('The addition is : ' + Addition(30,40));
// console.log('The product is : ' + Product(2,5));

